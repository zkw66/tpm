<script>
  export default {
    name: 'User_develop'
  }
</script>
<template>
    <div>
      培养方案查询页面
    </div>
</template>



<style scoped>

</style>
