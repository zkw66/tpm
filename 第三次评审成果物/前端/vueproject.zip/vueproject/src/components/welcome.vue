<template>
  <div>
    <h3>轻量级培养方案管理系统</h3>
  </div>
</template>

<script>
  export default {
    name: 'welcome'
  }
</script>

<style scoped>

</style>
