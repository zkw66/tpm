<template>

  <el-card>
    <el-breadcrumb separator="/">
      <el-breadcrumb-item>课程负责人</el-breadcrumb-item>
      <el-breadcrumb-item>课程信息管理</el-breadcrumb-item>
    </el-breadcrumb>
    <div class="searchForm">

      <el-form :inline="true" class="demo-form-inline">
        <el-form-item>
          <el-input v-model="queryInfo.query" placeholder="请输入课程代码" clearable @clear="getUserList"></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="" @click="getCourseList" icon="el-icon-search">查询</el-button>
        </el-form-item>
        <el-button style="position: absolute; right: 720px" type="" @click="addDialogVisible=true">添加课程</el-button>
      </el-form>



      <el-dialog title="添加课程" :visible.sync="addDialogVisible" width="40%" @close="addDialogClose">
        <el-form :model="addForm" :rules="addFormRules" ref="addFormRef" label-width="100px">

          <el-form-item label="课程编号" prop="courseid">
            <el-input v-model="addForm.courseid"></el-input>
          </el-form-item>

          <el-form-item label="课程名" prop="cname">
            <el-input v-model="addForm.cname" ></el-input>
          </el-form-item>

          <el-form-item label="课程学分" prop="points">
            <el-select v-model="addForm.points" placeholder="请选择">
              <el-option label="1" value="1"></el-option>
              <el-option label="2" value="2"></el-option>
              <el-option label="3" value="3"></el-option>
              <el-option label="4" value="4"></el-option>
              <el-option label="5" value="5"></el-option>
              <el-option label="6" value="6"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item label="课程学时" prop="period">
            <el-input v-model="addForm.period"></el-input>
          </el-form-item>

          <el-form-item label="理论学时" prop="theory">
            <el-input v-model="addForm.theory"></el-input>
          </el-form-item>
          <el-form-item label="实验学时" prop="practice">
            <el-input v-model="addForm.practice"></el-input>
          </el-form-item>

          <el-form-item label="所属专业" prop="major">
            <el-input v-model="addForm.major"></el-input>
          </el-form-item>

          <el-form-item label="所属负责人" prop="username" >  {{this.$session.get('bull')}}
            <el-input v-model="addForm.username" v-show="false" readonly="readonly"></el-input>
          </el-form-item>



          <el-form-item label="课程性质" prop="attribute">
            <el-input v-model="addForm.attribute"></el-input>
          </el-form-item>

        </el-form>

        <div slot="footer" class="dialog-footer">
          <el-button @click="addDialogVisible = false">取 消</el-button>
          <el-button type="primary" @click="addCourseBase">确 认</el-button>
        </div>
      </el-dialog>



      <el-table :header-cell-style="{background:'#808080',color:'#FFFFFF'}" border stripe :data="List" style="width: 100%">
        <el-table-column type="index"  width="80" label="序号" align="center">
        </el-table-column>
        <el-table-column prop="courseid" label="课程编号" width="160" align="center">
        </el-table-column>
        <el-table-column prop="cname" label="课程名" width="180" align="center">
        </el-table-column>
        <el-table-column prop="points" label="学分" align="center">
        </el-table-column>
        <el-table-column prop="period" label="总学时" align="center">
        </el-table-column>
        <el-table-column prop="theory" label="理论学时" align="center">
        </el-table-column>
        <el-table-column prop="practice" label="实验学时" align="center">
        </el-table-column>
        <el-table-column prop="major" label="专业" align="center">
        </el-table-column>
        <el-table-column prop="username" label="课程负责人" align="center">
        </el-table-column>
        <el-table-column prop="attribute" label="课程性质" align="center">
        </el-table-column>



        <el-table-column label="修改  /  删除" align="center">
          <template slot-scope="scope">
            <el-tooltip class="item" effect="dark" content="编辑课程" placement="top-start">
              <el-button  icon="el-icon-edit" circle @click="editCourse(scope.row.courseid)"></el-button>
            </el-tooltip>
            <el-tooltip class="item" effect="dark" content="删除课程" placement="top-start">
              <el-button type="" icon="el-icon-delete" circle @click="deleteCourse(scope.row.courseid)"></el-button>
            </el-tooltip>
          </template>
        </el-table-column>

        <el-table-column label="详情  /  发布" align="center">
          <template slot-scope="scope">
            <el-tooltip class="item" effect="dark" content="课程详情" placement="top-start">
              <el-button  icon="el-icon-tickets" circle @click="showCourse(scope.row.courseid)"></el-button>
            </el-tooltip>
            <el-tooltip class="item" effect="dark" content="发布课程" placement="top-start">
              <el-button type="" icon="el-icon-upload2" circle  @click="makeCourse(scope.row.courseid)"></el-button>
            </el-tooltip>
          </template>
        </el-table-column>

      </el-table>
      <el-dialog title="修改课程信息" :visible.sync="editDialogVisible" width="50%" @close="editDialogClose" append-to-body = "true">
        <el-form :model="editForm" :rules="editFormRules" ref="editFormRef" label-width="100px">

          <el-form-item label="学分" prop="points">
            <el-input v-model="editForm.points" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="总学时" prop="period">
            <el-input v-model="editForm.period" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="理论学时" prop="theory">
            <el-input v-model="editForm.theory" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="实验学时" prop="practice">
            <el-input v-model="editForm.practice" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="专业" prop="major">
            <el-input v-model="editForm.major" autocomplete="off"></el-input>
          </el-form-item>


        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="editDialogVisible = false">取 消</el-button>
          <el-button type="primary" @click="editCourseInfo">修 改</el-button>
        </div>
      </el-dialog>



      <el-dialog title="课程详细信息" :visible.sync="infoDialogVisible" width="50%" @close="editDialogClose" append-to-body = "true">
        <el-form :model="editForm" :rules="editFormRules" ref="editFormRef" label-width="100px">

          <el-form-item label="学分" prop="points">
            <el-input v-model="editForm.points" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="总学时" prop="period">
            <el-input v-model="editForm.period" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="理论学时" prop="theory">
            <el-input v-model="editForm.theory" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="实验学时" prop="practice">
            <el-input v-model="editForm.practice" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="专业" prop="major">
            <el-input v-model="editForm.major" autocomplete="off"></el-input>
          </el-form-item>


        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="editDialogVisible = false">取 消</el-button>
          <el-button type="primary" @click="editCourseInfo">修 改</el-button>
        </div>
      </el-dialog>
    </div>

    <div>
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="queryInfo.pageNum"
        :page-sizes="[4]"
        :page-size="queryInfo.pageSize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="total">
      </el-pagination>
    </div>
  </el-card>

</template>


<script>
  export default {

    create(){
      this.getCourseList();
    },
    data() {
      return {
        queryInfo:{
          query:'',//查询信息
          role:this.$session.get('bull'),
          pageNum:1,
          pageSize:4
        },
        List:[],
        total:0,
        addDialogVisible:false,
        editDialogVisible:false,
        infoDialogVisible:false,

        addForm:{
          cname:'',
          username:this.$session.get('bull'),
          points:'',
          period:'',
          theory:'',
          practice:'',
          courseid:'',
          major:'',
          attribute:''
        },
        editForm:{
          password:'',
          memorandum:''
        },
        infoForm:{
          courseid:'',
          ord:'',
          coursedata:'',
          coursetime:'',
          goal:'',
          secondindicid:'',
        },
        addFormRules: {
          cname: [
            { required: true, message: '请输入正确课程名', trigger: 'blur' },
            { min: 3, max: 10, message: '长度在 3 到 10 个字符', trigger: 'blur' }
          ],

          points:[
            { required: true, message:'请选择学分', trigger: 'blur' }
          ],
          period:[
            { required: true, message:'请输入学时', trigger: 'blur' }
          ],
          attribute:[
            { required: true, message:'请输入课程性质', trigger: 'blur' }
          ],
          theory:[
            { required: true, message:'请输入理论学时', trigger: 'blur' }
          ],
          practice:[
            { required: true, message:'请输入实验学时', trigger: 'blur' }
          ],
          major:[
            { required: true, message:'请输入专业', trigger: 'blur' }
          ],
          courseid:[
            { required: true, message:'请输入ID', trigger: 'blur'}
          ],
        },

        editFormRules: {
          password: [
            { required: true, message: '请输入密码', trigger: 'blur' },
            { min: 3, max: 10, message: '长度在 3 到 10 个字符', trigger: 'blur' }
          ]
        },
        infoFormRules: {

        },

      }
    },


    methods: {
      async getCourseList () {
        const { data: res } = await this.$http.get("Courses/AllCourse", { params: this.queryInfo })
        this.List = res.data;
        this.total = res.numbers;
      },
      showCourse (courseid) {
        this.$session.set("bulls",courseid);
        this.$router.push({path:'/Course_home'});


      },
      async makeCourse(courseid){
        const { data: res } = await this.$http.put("Courses/CourseState?state=1&courseid="+courseid+'');
        console.log(res);
        if (res !== "success") return this.$message.error("发布失败");
        this.$message.success("发布成功");
        this.getCourseList();
      },

      editCourseInfo () {
        this.$refs.editFormRef.validate(async valid => {
          console.log(valid);
          if (!valid) return;

          const { data: res } = await this.$http.put("Courses/Course", this.editForm);
          console.log(res);
          if (res !== "success") return this.$message.error("修改失败");
          this.$message.success("修改成功");

          this.editDialogVisible = false;
          this.getCourseList();
        });
      },
      async editCourse(courseid){
        const {data:res} = await this.$http.get("Courses/CourseMessage?courseid="+courseid);
        this.editForm = res;
        this.editDialogVisible = true;
      },
      async deleteCourse (courseid) {

        const confirmResult = await this.$confirm('是否删除该课程？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).catch(err => err)
        if (confirmResult !== 'confirm') {
          return ;
        }
        const { data: res } = await this.$http.delete("Courses/Course?courseid=" + courseid);
        if (res !== "success") {
          return this.$message.error("删除失败");
        }
        this.$message.success("删除成功");
        this.getCourseList();
      },
      addCourseBase () {
        this.$refs.addFormRef.validate(async valid => {
          if (!valid) return;
          const { data: res } = await this.$http.post("Courses/Course", this.addForm);
          if (res !== "success") {
            return this.$message.error("添加失败!")
          }
          this.$message.success("添加成功！")
          this.addDialogVisible = false;
          this.getCourseList();
        })
      },
      handleSizeChange (newSize) {
        this.queryInfo.pageSize = newSize;
        this.getCourseList();
      },
      handleCurrentChange (newPage) {
        this.queryInfo.pageNum = newPage;
        this.getCourseList();
      },
      addDialogClose () {
        this.$refs.addFormRef.resetFields();
      },
      editDialogClose () {
        this.$refs.editFormRef.resetFields();
      },
    }
  }
</script>




<style scoped>
  .searchForm{
    margin-top: 40px;
  }
</style>
