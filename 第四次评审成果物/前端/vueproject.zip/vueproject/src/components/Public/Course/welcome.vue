
<template>
  <div>
    <el-container>

      <el-header height="60px">
        <div>
          <span>轻量级培养方案管理系统</span>
        </div>
        <div>
          <el-button type="danger" @click="logout" round icon="el-icon-refresh-right" plain>退出登录</el-button>
        </div>

      </el-header>
      <el-container>
        <el-header width="100px">
          <el-menu
            class="el-menu--horizontal"
            @open="handleOpen"
            @close="handleClose"
            background-color="white"
            text-color="black"
            active-text-color="black"
            unique-opened
            router
            :collapse-transition="true">
            <el-menu-item index="/welcome"><i class="el-icon-school"></i>课程大纲</el-menu-item>
            <el-menu-item index="/Curriculum_relation"><i class="el-icon-files"></i>培养方案</el-menu-item>
          </el-menu>
        </el-header>

      </el-container>
    </el-container>
    <el-card>
      <el-breadcrumb separator="/">
        <el-breadcrumb-item>公众</el-breadcrumb-item>
        <el-breadcrumb-item>课程信息</el-breadcrumb-item>
      </el-breadcrumb>
     <div class="searchForm">

      <el-form :inline="true" class="demo-form-inline">
        <el-form-item>
          <el-input v-model="queryInfo.query" placeholder="请输入课程代码" clearable @clear="getUserList"></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="" @click="getCourseList" icon="el-icon-search">查询</el-button>
        </el-form-item>
      </el-form>

      

       <el-table :header-cell-style="{background:'#808080',color:'#FFFFFF'}" border stripe :data="List" style="width: 100%">
        <el-table-column type="index"  width="80" label="序号" align="center">
        </el-table-column>
        <el-table-column prop="courseid" label="课程编号" width="160" align="center">
        </el-table-column>
        <el-table-column prop="cname" label="课程名" width="180" align="center">
        </el-table-column>
        <el-table-column prop="points" label="学分" align="center">
        </el-table-column>
        <el-table-column prop="period" label="总学时" align="center">
        </el-table-column>
        <el-table-column prop="theory" label="理论学时" align="center">
        </el-table-column>
        <el-table-column prop="practice" label="实验学时" align="center">
        </el-table-column>
        <el-table-column prop="major" label="专业" align="center">
        </el-table-column>
        <el-table-column prop="username" label="课程负责人" align="center">
        </el-table-column>
        <el-table-column prop="attribute" label="课程性质" align="center">
        </el-table-column>


        <el-table-column label="详情" align="center">
          <template slot-scope="scope">
            <el-tooltip class="item" effect="dark" content="课程详情" placement="top-start">
              <el-button  icon="el-icon-tickets" circle @click="showCourse(scope.row.courseid)"></el-button>
            </el-tooltip>
          </template>
        </el-table-column>

      </el-table>
      </div>

      <div>
        <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page="queryInfo.pageNum"
                :page-sizes="[4]"
                :page-size="queryInfo.pageSize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="total">
        </el-pagination>
      </div>
    </el-card>
  </div>
</template>


<script>
  export default {

    create(){
      this.getCourseList();
    },
    data() {
      return {
        queryInfo:{
          query:'',//查询信息
          role:'',
          pageNum:1,
          pageSize:4
        },
        List:[],
        total:0,
        addDialogVisible:false,
        editDialogVisible:false,
        infoDialogVisible:false,
        Form:{
          courseid:'',
          ord:'',
          coursedata:'',
          coursetime:'',
          goal:'',
          secondindicid:'',

        },
        FormRules: {

        },



      }
    },


    methods: {
      async getCourseList () {
        const { data: res } = await this.$http.get("Publics/AllCourse", { params: this.queryInfo })
        this.List = res.data;
        this.total = res.numbers;
      },
    
      handleSizeChange (newSize) {
        this.queryInfo.pageSize = newSize;
        this.getCourseList();
      },
      handleCurrentChange (newPage) {
        this.queryInfo.pageNum = newPage;
        this.getCourseList();
      },
      logout(){
        window.sessionStorage.clear();
        this.$router.push({ path: "/login"});
      },
      showCourse (courseid) {
        this.$session.set("bulls",courseid);
        window.sessionStorage.setItem('token',"public");
        this.$router.push({path:'/Pub_base'});
      },
    }
  }
</script>




<style scoped>
  .el-header{
    background: lightslategray;
    color: white;
    font-size: 25px;
    align-items: center;
    justify-content: space-between;
    display: flex;
  }
  .el-main{
    background-color: whitesmoke;
  }

</style>
