<template>
  <div>
    <el-container>

      <el-header height="60px">
        <div>
          <span>轻量级培养方案管理系统</span>
        </div>
        <div>
          <el-button type="danger" @click="logout" round icon="el-icon-refresh-right" plain>退出登录</el-button>
        </div>






      </el-header>
      <el-container>
        <el-header width="100px">
          <el-menu
            class="el-menu--horizontal"
            @open="handleOpen"
            @close="handleClose"
            background-color="white"
            text-color="black"
            active-text-color="black"
            unique-opened
            router
            :collapse-transition="true">
            <el-menu-item index="/Pub_base"><i class="el-icon-lightning"></i>课程基本信息</el-menu-item>
            <el-menu-item index="/Pub_detail"><i class="el-icon-school"></i>课程详细内容信息</el-menu-item>
            <el-menu-item index="/Pub_ref"><i class="el-icon-files"></i>课程先修后修</el-menu-item>
            <el-menu-item index="/Pub_book"><i class="el-icon-lightning"></i>课程参考书目</el-menu-item>
          </el-menu>
        </el-header>

      </el-container>
    </el-container>
    <el-card>
      <el-breadcrumb separator="/">
        <el-breadcrumb-item>公众</el-breadcrumb-item>
        <el-breadcrumb-item>课程信息</el-breadcrumb-item>
        <el-breadcrumb-item>课程参考书目</el-breadcrumb-item>
      </el-breadcrumb>
      <div class="searchForm">

        <el-form :inline="true" class="demo-form-inline">
          <el-form-item>
            <el-input v-model="queryInfo.query" placeholder="请输入书籍名称" clearable @clear="getCourseList"></el-input>
          </el-form-item>
          <el-form-item>
            <el-button type="" @click="getCourseList" icon="el-icon-search">查询</el-button>
          </el-form-item>
        </el-form>


        <el-table :header-cell-style="{background:'#808080',color:'#FFFFFF'}" border stripe :data="List" style="width: 100%">

          <el-table-column prop="courseid" label="课程编号" width="160" align="center">
          </el-table-column>
          <el-table-column prop="types" label="参考类型" width="160" align="center">
          </el-table-column>
          <el-table-column prop="author" label="作者" width="400" align="center">
          </el-table-column>
          <el-table-column prop="bookname" label="书名" width="360" align="center">
          </el-table-column>

          <el-table-column prop="press" label="出版社" width="210" align="center">
          </el-table-column>

          <el-table-column prop="presstime" label="出版时间" width="200" align="center">
          </el-table-column>

        </el-table>
      </div>

      <div>
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="queryInfo.pageNum"
          :page-sizes="[4]"
          :page-size="queryInfo.pageSize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="total">
        </el-pagination>
      </div>
    </el-card>
  </div>
</template>


<script>
  export default {

    create(){
      this.getCourseList();
    },
    data() {
      return {
        queryInfo:{
          query:'',//查询信息
          role:this.$session.get('bulls'),
          pageNum:1,
          pageSize:4
        },
        List:[],
        total:0,
        addDialogVisible:false,
        editDialogVisible:false,
        infoDialogVisible:false,
        Form:{
          courseid:this.$session.get('bulls'),
          types:'',
          author:'',
          bookname:'',
          press:'',
          presstime:'',
        },
        FormRules: {

        },



      }
    },


    methods: {
      async getCourseList () {
        const { data: res } = await this.$http.get("Publics/AllCourseBook" ,{ params: this.queryInfo });
        this.List = res.data;
        this.total = res.numbers;
      },
      handleSizeChange (newSize) {
        this.queryInfo.pageSize = newSize;
        this.getCourseList();
      },
      handleCurrentChange (newPage) {
        this.queryInfo.pageNum = newPage;
        this.getCourseList();
      },
      logout(){
        window.sessionStorage.clear();
        this.$router.push({ path: "/login"});
      },
    }
  }
</script>




<style scoped>
  .el-header{
    background: lightslategray;
    color: white;
    font-size: 25px;
    align-items: center;
    justify-content: space-between;
    display: flex;
  }
  .el-main{
    background-color: whitesmoke;
  }

</style>
