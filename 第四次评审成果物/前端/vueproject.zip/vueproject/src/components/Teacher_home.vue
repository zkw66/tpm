<template>

<div>


<router v-bind:msg="this.$route.query.variable"></router>




  <el-container>

    <el-header height="60px">
      <div>
        <span>轻量级培养方案管理系统</span>
      </div>
      <div>
        <el-button type="danger" @click="logout" round icon="el-icon-refresh-right" plain>退出登录</el-button>
      </div>






    </el-header>
    <el-container>
      <el-header width="100px">
        <el-menu
          class="el-menu--horizontal"
          @open="handleOpen"
          @close="handleClose"
          background-color="white"
          text-color="black"
          active-text-color="black"
          unique-opened
          router
          :collapse-transition="true">
              <el-menu-item index="/manageCourse"><i class="el-icon-school"></i>课程信息管理</el-menu-item>
        </el-menu>
      </el-header>
      <el-main>
        <router-view></router-view>
      </el-main>
    </el-container>
  </el-container>
</div>
</template>


<script>
  import router from "../router";


  export default {


    name: 'home',
    methods: {
      handleOpen(key, keyPath) {
        console.log(key, keyPath);
      },
      handleClose(key, keyPath) {
        console.log(key, keyPath);
      },
      logout(){
        window.sessionStorage.clear();
        this.$router.push({ path: "/login"});
      }
    }
  }

</script>

<style scoped>
  .el-header{
    background: lightslategray;
    color: white;
    font-size: 25px;
    align-items: center;
    justify-content: space-between;
    display: flex;
  }
  .el-main{
    background-color: whitesmoke;
  }

</style>
