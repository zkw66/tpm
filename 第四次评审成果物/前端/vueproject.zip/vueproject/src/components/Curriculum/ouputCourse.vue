<template>
    <div>Under Construction</div>
</template>

<script>
  export default {
    name: 'exportCourse'
  }
</script>

<style scoped>

</style>
