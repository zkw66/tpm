
<template>
<div>
  <el-container>

    <el-header height="60px">
      <div>
        <span>轻量级培养方案管理系统</span>
      </div>
      <div>
        <el-button type="danger" @click="logout" round icon="el-icon-refresh-right" plain>退出登录</el-button>

      </div>






    </el-header>
    <el-container>
      <el-header width="100px">
        <el-menu
          class="el-menu--horizontal"
          @open="handleOpen"
          @close="handleClose"
          background-color="white"
          text-color="black"
          active-text-color="black"
          unique-opened
          router
          :collapse-transition="true">
          <el-menu-item index="/FundamentalInfo"><i class="el-icon-lightning"></i>课程基本信息</el-menu-item>
          <el-menu-item index="/Course_home"><i class="el-icon-school"></i>课程详细内容信息</el-menu-item>
          <el-menu-item index="/Curriculum_relation"><i class="el-icon-files"></i>课程先修后修</el-menu-item>
          <el-menu-item index="/References"><i class="el-icon-lightning"></i>课程参考书目</el-menu-item>
        </el-menu>
      </el-header>

    </el-container>
  </el-container>
  <el-card>
    <el-breadcrumb separator="/">
      <el-breadcrumb-item>课程负责人</el-breadcrumb-item>
      <el-breadcrumb-item>课程信息管理</el-breadcrumb-item>
      <el-breadcrumb-item>课程详细内容信息</el-breadcrumb-item>
    </el-breadcrumb>
    <div class="searchForm">

      <el-form :inline="true" class="demo-form-inline">
        <el-form-item>
          <el-input v-model="queryInfo.query" placeholder="请输入章节顺序" clearable @clear="getCourseList"></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="" @click="getCourseList" icon="el-icon-search">查询</el-button>
        </el-form-item>
        <el-button style="position: absolute; right: 720px" type="" @click="addDialogVisible=true">添加章节</el-button>
        <el-button style="position: absolute; right: 100px" @click="exports">导出PDF</el-button>
      </el-form>

      <el-dialog title="添加章节" :visible.sync="addDialogVisible" width="40%" @close="addDialogClose">
        <el-form :model="addForm" :rules="FormRules" ref="addFormRef" label-width="100px">

          <el-form-item label="课程编号" prop="courseid">{{this.$session.get('bulls')}}
            <el-input v-model="addForm.courseid" v-show="false" readonly="readonly"></el-input>
          </el-form-item>


          <el-form-item label="顺序" prop="ord">
            <el-input v-model="addForm.ord"></el-input>
          </el-form-item>

          <el-form-item label="章节" prop="username" >
            <el-input v-model="addForm.coursedata" ></el-input>
          </el-form-item>



          <el-form-item label="时长" prop="attribute">
            <el-input v-model="addForm.coursetime"></el-input>
          </el-form-item>
          <el-form-item label="目标" prop="attribute">
            <el-input v-model="addForm.goal"></el-input>
          </el-form-item>
          <el-form-item label="二级信息" prop="attribute">
            <el-input v-model="addForm.secondindicid"></el-input>
          </el-form-item>
        </el-form>

        <div slot="footer" class="dialog-footer">
          <el-button @click="addDialogVisible = false">取 消</el-button>
          <el-button type="primary" @click="addCourseParagraph">确 认</el-button>
        </div>
      </el-dialog>





      <div id = "pdfDom">
      <el-table :header-cell-style="{background:'#808080',color:'#FFFFFF'}" border stripe :data="List" style="width: 100%">

        <el-table-column prop="courseid" label="课程编号" width="160" align="center">
        </el-table-column>
        <el-table-column prop="ord" label="顺序" width="80" align="center">
        </el-table-column>
        <el-table-column prop="coursedata" label="章节" width="500" align="center">
        </el-table-column>
        <el-table-column prop="coursetime" label="时长" width="80" align="center">
        </el-table-column>
        <el-table-column prop="goal" label="目标" align="center">
        </el-table-column>
        <el-table-column prop="secondindicid" label="二级信息" align="center">
        </el-table-column>

        <el-table-column label="修改  /  删除" align="center">
          <template slot-scope="scope">
            <el-tooltip class="item" effect="dark" content="编辑章节" placement="top-start">
              <el-button  icon="el-icon-edit" circle @click="editParagraph(scope.row.courseid,scope.row.ord)"></el-button>
            </el-tooltip>
            <el-tooltip class="item" effect="dark" content="删除章节" placement="top-start">
              <el-button type="" icon="el-icon-delete" circle @click="deleteParagraph(scope.row.courseid,scope.row.ord)"></el-button>
            </el-tooltip>
          </template>
        </el-table-column>


      </el-table>
      </div>

      <el-dialog title="修改课程信息" :visible.sync="editDialogVisible" width="50%" @close="editDialogClose" append-to-body = "true">
        <el-form :model="editForm" :rules="editFormRules" ref="editFormRef" label-width="100px">


          <el-form-item label="章节" prop="coursedata">
            <el-input v-model="editForm.coursedata" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="时长" prop="coursetime">
            <el-input v-model="editForm.coursetime" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="目标" prop="goal">
            <el-input v-model="editForm.goal" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="二级信息" prop="secondindicid">
            <el-input v-model="editForm.secondindicid" autocomplete="off"></el-input>
          </el-form-item>

        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="editDialogVisible = false">取 消</el-button>
          <el-button type="primary" @click="editParagraphInfo">修 改</el-button>
        </div>
      </el-dialog>

    </div>

    <div>
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="queryInfo.pageNum"
        :page-sizes="[4]"
        :page-size="queryInfo.pageSize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="total">
      </el-pagination>
    </div>
  </el-card>
</div>
</template>


<script>
  export default {

    create(){
      this.getCourseList();
    },
    data() {
      return {
        fileName: this.$session.get('bulls') + '课程详细内容信息',
        queryInfo:{
          query:'',//查询信息
          role:this.$session.get('bulls'),
          pageNum:1,
          pageSize:4
        },
        List:[],
        total:0,
        addDialogVisible:false,
        editDialogVisible:false,
        infoDialogVisible:false,
        Form:{
          courseid:'',
          ord:'',
          coursedata:'',
          coursetime:'',
          goal:'',
          secondindicid:'',

        },
        addForm:{
          courseid:this.$session.get('bulls'),
          ord:'',
          coursedata:'',
          coursetime:'',
          goal:'',
          secondindicid:'',

        },
        editForm:{
          coursedata:'',
          coursetime:'',
          goal:'',
          secondindicid:'',
        },
        editFormRules: {
          coursedata: [
            { required: true, message: '请输入章节信息', trigger: 'blur' },
          ],
          coursetime: [
            { required: true, message: '请输入时长', trigger: 'blur' },

          ],
          goal: [
            { required: true, message: '请输入章节目标', trigger: 'blur' },
          ],

          secondindicid: [
            { required: true, message: '请输入二级信息', trigger: 'blur' },

          ]

        },
        addFormRules: {
          courseid: [
            { required: true, message: '请输入课程编号', trigger: 'blur' },
          ],
          ord: [
            { required: true, message: '请输入顺序', trigger: 'blur' },

          ],
          coursedata: [
            { required: true, message: '请输入章节信息', trigger: 'blur' },
          ],

          coursetime: [
            { required: true, message: '请输入时长', trigger: 'blur' },

          ],
          goal: [
            { required: true, message: '请输入章节目标', trigger: 'blur' },

          ],
          secondindicid: [
            { required: true, message: '请输入二级信息', trigger: 'blur' },

          ]

        },
        FormRules: {

        },



      }
    },


    methods: {
      exports () {
			    this.getPdf('pdfDom', this.fileName)
		  },
      async getCourseList () {
        const { data: res } = await this.$http.get("CourseDetails/AllCourseDetail" ,{ params: this.queryInfo });
        this.List = res.data;
        this.total = res.numbers;
      },
      editParagraphInfo () {
        this.$refs.editFormRef.validate(async valid => {
          console.log(valid);
          if (!valid) return;

          const { data: res } = await this.$http.put("CourseDetails/CourseDetail", this.editForm);
          console.log(res);
          if (res !== "success") return this.$message.error("修改失败");
          this.$message.success("修改成功");

          this.editDialogVisible = false;
          this.getCourseList();
        });
      },
      async editParagraph(courseid,ord){
        const {data:res} = await this.$http.get("CourseDetails/CourseDetailMessage?courseid="+courseid+"&ord="+ord+"");
        this.editForm = res;
        this.editDialogVisible = true;
      },
      handleSizeChange (newSize) {
        this.queryInfo.pageSize = newSize;
        this.getCourseList();
      },
      handleCurrentChange (newPage) {
        this.queryInfo.pageNum = newPage;
        this.getCourseList();
      },
      addDialogClose () {
        this.$refs.addFormRef.resetFields();
      },
      editDialogClose () {
        this.$refs.editFormRef.resetFields();
      },
      logout(){
        window.sessionStorage.clear();
        this.$router.push({ path: "/login"});
      },

      async deleteParagraph (courseid,ord) {

        const confirmResult = await this.$confirm('是否删除该章节？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).catch(err => err)
        if (confirmResult !== 'confirm') {
          return ;
        }
        const { data: res } = await this.$http.delete("CourseDetails/CourseDetail?courseid="+ courseid+"&ord="+ord+"");
        if (res !== "success") {
          return this.$message.error("删除失败");
        }
        this.$message.success("删除成功");
        this.getCourseList();
      },
      addCourseParagraph () {
        this.$refs.addFormRef.validate(async valid => {
          if (!valid) return;
          const { data: res } = await this.$http.post("CourseDetails/CourseDetail", this.addForm);
          if (res !== "success") {
            return this.$message.error("添加失败!")
          }
          this.$message.success("添加成功！")
          this.addDialogVisible = false;
          this.getCourseList();
        })
      },
    }
  }
</script>




<style scoped>
  .el-header{
    background: lightslategray;
    color: white;
    font-size: 25px;
    align-items: center;
    justify-content: space-between;
    display: flex;
  }
  .el-main{
    background-color: whitesmoke;
  }

</style>
