<script>
  export default {
    name: 'Professor_home'
  }
</script>
<template>
    <div>专业负责人页面</div>
</template>



