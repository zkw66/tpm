import Vue from 'vue'
import VueRouter from 'vue-router'
import login from '../components/login.vue'
import home from '../components/home'
import welcome from '../components/Public/Course/welcome'
import User_stu from '../components/User/User_stu'
import Teacher_home from '../components/Teacher_home'
import Profess_home from '../components/Professor_home'
import manage_Course from '../components/Curriculum/manage_Course'
import editCourse from '../components/Curriculum/editInfo'
import exportCourse from '../components/Curriculum/ouputCourse'
import Visitor from '../components/User/Visitor'
import Manager_home from '../components/Admin_home'
import addUser from '../components/Admin/addUser'
import Check_user from '../components/Admin/Check_user'
import Check_course from '../components/Admin/Check_course'
import Course_home from "../components/Course_home";
import Curriculum_relation from "../components/Curriculum_relation";
import References from "../components/References";
import Pub_ref from "../components/Public/Course/Pub_ref";
import Pub_base from "../components/Public/Course/Pub_base";
import Pub_book from "../components/Public/Course/Pub_book";
import Pub_detail from "../components/Public/Course/Pub_detail";
import FundamentalInfo from "../components/FundamentalInfo";
import test from "../components/test";
Vue.use(VueRouter)

const routes = [

  { path: '/', redirect: '/login' },
  { path: '/login', component: login,meta:{title:'轻量级培养方案管理系统'}},
  { path: '/Manager_home',component: Manager_home,
    children: [
      { path: '/addUser', component: addUser},
      { path: '/Check_user', component: Check_user},
      { path: '/Check_course',component: Check_course}
      ]},
  { path: '/Teacher_home',component: Teacher_home,
    children: [

      { path: '/manageCourse',component: manage_Course},
      { path: '/editCourse',component: editCourse},
      { path: '/exportCourse',component: exportCourse},
    ]
  },



  {name:'Course_home', path: '/Course_home', component: Course_home},
  {name:'Curriculum_relation', path: '/Curriculum_relation', component: Curriculum_relation},
  {name:'References', path: '/References', component: References},
  {name:'Pub_ref', path: '/Pub_ref', component: Pub_ref},
  {name:'Pub_base', path: '/Pub_base', component: Pub_base},
  {name:'Pub_detail', path: '/Pub_detail', component: Pub_detail},
  {name:'Pub_book', path: '/Pub_book', component: Pub_book},
  {name:'FundamentalInfo', path: '/FundamentalInfo', component: FundamentalInfo},
  {name:'test', path: '/test', component: test},



  { path: '/welcome', component: welcome },
  { path: '/Visitor', component: Visitor },
  { path: '/User_stu', component: User_stu },



  { path: '/welcome',component: welcome,
    children: [

      { path: '/Visitor',component: Visitor},
      { path: '/User_stu',component: User_stu},
    ]
  },




  { path: '/Professor_home',component: Profess_home,
    children: [
    ]
  }
]

const router = new VueRouter({
  routes
})
router.beforeEach((to, from, next) => {
  //项目标题
  if(to.meta.title){
    document.title = to.meta.title
  }

  if(to.path==='/login'||to.path==='/welcome')return next();

  //有问题

  const tokenStr1=window.sessionStorage.getItem('token')
  if (!tokenStr1){
    return next('/login');
  }
  next()
})
export default router
